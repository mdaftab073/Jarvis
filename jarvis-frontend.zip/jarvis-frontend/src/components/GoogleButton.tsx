import { useEffect, useRef, useState } from 'react';

declare global { interface Window { google?: any } }
const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined;

function loadScript(): Promise<void> {
  return new Promise((res, rej) => {
    if (window.google?.accounts?.id) return res();
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = () => res();
    s.onerror = () => rej(new Error('Google sign-in could not load. Check your connection or ad blocker.'));
    document.head.appendChild(s);
  });
}

/** Google Identity Services button → returns a Google ID token to the caller. */
export function GoogleButton({ onToken, onError }: { onToken: (t: string) => void; onError: (m: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (!CLIENT_ID) { onError('Set VITE_GOOGLE_CLIENT_ID in .env to enable sign-in.'); return; }
    loadScript().then(() => {
      window.google.accounts.id.initialize({ client_id: CLIENT_ID, callback: (r: any) => r?.credential ? onToken(r.credential) : onError('Google did not return a credential.') });
      window.google.accounts.id.renderButton(ref.current, { theme: 'outline', size: 'large', text: 'signin_with', width: 280 });
      setReady(true);
    }).catch((e) => onError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <div ref={ref} aria-label="Sign in with Google" style={{ minHeight: 44 }}>{!ready && CLIENT_ID && <span className="muted">Loading Google sign-in…</span>}</div>;
}
